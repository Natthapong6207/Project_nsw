import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { type } from "os";
import { createData } from "../interfaces/createData";
import { RootState } from "../store/store";

type tableState = [{
    id: number,
    min: number,
    max: number,
    fee: number,
    loading: boolean,
}];

const initialValues:tableState = [{
    id: 1,
    min:1,
    max:1000,
    fee:5.0,
    loading:false,
}];
 
const tableSlice = createSlice({
    name: "table",
    initialState:initialValues ,
    reducers:{
        increase:(state: tableState,actions:PayloadAction<void>) =>{

        },
    },
    extraReducers:(builder) => {

    }
});


export const { increase } = tableSlice.actions;
export const  tableSelector = (store: RootState) => store.tableReducer;
export default tableSlice.reducer;
