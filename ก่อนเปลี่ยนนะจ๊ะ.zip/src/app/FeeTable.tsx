import React,{ useState } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Container } from '@mui/system';
import AddIcon from '@mui/icons-material/AddCircleRounded';
import RemoveIcon from '@mui/icons-material/RemoveCircleRounded';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import AppleIcon from '@mui/icons-material/Apple';
import StarIcon from '@mui/icons-material/StarHalfRounded';
import AdbRoundedIcon from '@mui/icons-material/AdbRounded';
import { useAppDispatch } from '../store/store';
import tableSlice, { increase, tableSelector } from '../slices/tableSlice';
import { useSelector } from 'react-redux';

type Props = {

}

export default function FeeTable({}: Props) {
  const dispatch = useAppDispatch();
  const tableReducer = useSelector(tableSelector);

  const rows = [
    tableReducer,
  ];

  const [data, setData] = useState(rows);
  
  const handlePlus = () =>{
    const lastRows = data[data.length-1];
    console.log(lastRows);  
    setData([...data,]);
    console.log(data);  
  }

  return (
    <div>
        <Container>
      <AppleIcon/>
      <AdbRoundedIcon/>
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>ID</TableCell>
            <TableCell align="right">MIN</TableCell>
            <TableCell align="right">MAX</TableCell>
            <TableCell align="right">FEE</TableCell>
            <TableCell align="right">ACTIONS</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {tableReducer.map((row) => (
            <TableRow
              hover
              key={row.id}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.id}
              </TableCell>
              <TableCell align="right"><TextField variant="standard" type="number" disabled value={row.min}></TextField></TableCell>
              <TableCell align="right"><TextField variant="standard" type="number" placeholder='max' value={row.max}></TextField></TableCell>
              <TableCell align="right"><TextField variant="standard" type="number" placeholder='fee' ></TextField></TableCell>
         
              {tableReducer.length == 1 ? <>
              <TableCell align="right"><Button variant="contained" onClick={() =>{
                dispatch(increase())
              } }><AddIcon/></Button><Button hidden><RemoveIcon/></Button></TableCell>
              </>
              :
              row.id == tableReducer.length ?  <>

              <TableCell align="right"><Button variant="contained" onClick={handlePlus}><AddIcon /></Button>
                <Button variant="contained" onClick={ () => {
                    tableReducer.filter(a => a.id !== row.id)
                  
                }}><RemoveIcon/></Button></TableCell>
                </>

                : 
                
                <>
              
                <TableCell align="right">  <Button hidden><AddIcon/></Button>
                <Button  hidden><RemoveIcon/></Button> 
              </TableCell>
              </>
              }
              
              
                

            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    </Container>
    </div>
  )
}