import { Data } from "./Data";

export function createData(
    id: number,
    min: number,
    max: number,
    fee: number,
) : Data {
    return {
        id,
        min,
        max,
        fee,
    };
}