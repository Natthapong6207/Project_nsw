import { Data } from "./Data";

export interface HeadCell {
  disablePadding: boolean;
  label: string;
  numeric: boolean;
}