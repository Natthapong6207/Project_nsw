export interface Data {
    id: number;
    min: number;
    max: number;
    fee: number;
}
