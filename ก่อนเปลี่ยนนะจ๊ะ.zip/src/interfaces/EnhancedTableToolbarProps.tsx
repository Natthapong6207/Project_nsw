export interface EnhancedTableToolbarProps {
    numSelected: number;
}