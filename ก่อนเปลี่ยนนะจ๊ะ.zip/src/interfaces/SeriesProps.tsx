export interface SeriesProps {
    seriesList: {
        name: string;
        cover: string;
        imdb: number;
        seasons: number;
        genre: string;
    }[]
}