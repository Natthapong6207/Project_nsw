import { Data } from "../interfaces/Data";
import { EnhancedTableProps } from "../interfaces/EnhancedTableProps";
import Box from '@mui/material/Box';
import TableCell from '@mui/material/TableCell';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableSortLabel from '@mui/material/TableSortLabel';
import Checkbox from '@mui/material/Checkbox';
import { HeadCell } from "../interfaces/HeadCell";
import { visuallyHidden } from '@mui/utils';

const headCells: readonly HeadCell[] = [
    {
      numeric: false,
      disablePadding: true,
      label: 'NAME',
    },
    {
      numeric: true,
      disablePadding: false,
      label: 'IMG',
    },
    {
      numeric: true,
      disablePadding: false,
      label: 'GENRE',
    },
    {
      numeric: true,
      disablePadding: false,
      label: 'Seasons',
    },
    {
      numeric: true,
      disablePadding: false,
      label: 'IMDB',
    },
    {
      numeric: true,
      disablePadding: false,
      label: 'ACTION',
    },
  ];
  

export function EnhancedTableHead(props: EnhancedTableProps) {

  
    return (
      <TableHead>
        <TableRow>
          <TableCell padding="checkbox">
          </TableCell>
          {headCells.map((headCell) => (
            <TableCell
              align={headCell.numeric ? 'right' : 'left'}
              padding={headCell.disablePadding ? 'none' : 'normal'}
            >
              <TableSortLabel
              >
                {headCell.label}
                
              </TableSortLabel>
            </TableCell>
          ))}
        </TableRow>
      </TableHead>
    );
  }