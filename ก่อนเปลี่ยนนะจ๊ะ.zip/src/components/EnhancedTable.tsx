
import React,{ useState } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Container } from '@mui/system';
import { createDeflate } from 'zlib';
import { createData } from '../interfaces/createData';
import ReactDOM, { render } from 'react-dom';
import AddIcon from '@mui/icons-material/AddCircleRounded';
import RemoveIcon from '@mui/icons-material/RemoveCircleRounded';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import AppleIcon from '@mui/icons-material/Apple';
import StarIcon from '@mui/icons-material/StarHalfRounded';
import AdbRoundedIcon from '@mui/icons-material/AdbRounded';

const rows = [
  createData(1, 1, 1000, 5),
];

function BasicTable() {

  const [data, setData] = useState(rows);
  const [min, setMin] = useState("");
  const [max, setMax] = useState("");
  const [fee, setFee] = useState("");
  
  const handlePlus = () =>{
    const lastRows = data[data.length-1];
    console.log(lastRows);  
    setData([...data,createData(lastRows.id+1, parseInt(max)+1, 0, parseInt(fee))]);
    console.log(data);  
    setMin("");
    setMax("");
    setFee("");
  }

   return (
    <Container>
      <AppleIcon/>
      <AdbRoundedIcon/>
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>ID</TableCell>
            <TableCell align="right">MIN</TableCell>
            <TableCell align="right">MAX</TableCell>
            <TableCell align="right">FEE</TableCell>
            <TableCell align="right">ACTIONS</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {data.map((row) => (
            <TableRow
              hover
              key={row.id}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.id}
              </TableCell>
              <TableCell align="right"><TextField variant="standard" type="number" disabled value={row.min}></TextField></TableCell>
              <TableCell align="right"><TextField variant="standard" type="number" placeholder='max' value={row.max} onChange={(e) => setMax(e.target.value)}></TextField></TableCell>
              <TableCell align="right"><TextField variant="standard" type="number" placeholder='fee' onChange={(e) => setFee(e.target.value)}></TextField></TableCell>
         
              {data.length == 1 ? <>
              <TableCell align="right"><Button variant="contained" onClick={handlePlus}><AddIcon/></Button><Button hidden><RemoveIcon/></Button></TableCell>
              </>
              :
              row.id == data.length ?  <>

              <TableCell align="right"><Button variant="contained" onClick={handlePlus}><AddIcon /></Button>
                <Button variant="contained" onClick={ () => {
                  setData(
                    data.filter(a => a.id !== row.id)
                  )
                }}><RemoveIcon/></Button></TableCell>
                </>

                : 
                
                <>
              
                <TableCell align="right">  <Button hidden><AddIcon/></Button>
                <Button  hidden><RemoveIcon/></Button> 
              </TableCell>
              </>
              }
              
              
                

            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
    </Container>
  );
}

export default BasicTable;